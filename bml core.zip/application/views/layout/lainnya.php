<div class="container">
    <div class="row">
        <div class="col-md-6">
            <img src="https://investasi.online/wp-content/uploads/2019/09/Pengertian_Surat_Perizinan_Usaha_Perdagangan_Kegunaan_dan_Contohnya.jpg" width="100%">
        </div>
        <div class="col-md-6 subservices">
            <h1>Perizinan Lainnya</h1>
            <h5> Kami Melayani Meliputi Perizinan Lain yaitu:</h5>
            <div class="lainnya">
                <span><i class="fas fa-store"></i> PIRT</span><br>
                <span><i class="fas fa-prescription-bottle-alt"></i> Alat Kesehatan</span><br />
                <span><i class="far fa-copyright"></i> Merek</span><br />
            </div>
        </div>
    </div>
</div>