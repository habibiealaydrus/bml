<div class="container">
    <div class="row">
        <div class="col-md-6 subservices">
            <h1>Perizinan BPOM</h1>
            <h3>Kami Melayani Meliputi Perizinan BPOM</h3>
            <ul>
                <li>1. SKI (Surat Keterangan Impor) BPOM</li>
                <li>2. E-reg Pangan Olahan (ML-MD BPOM)</li>
                <li>3. SMKPO -CPPOB</li>
                <li>4. Izin edar Kosmetik (NA) </li>
                <li>5. Izin edar OT/Suplemen (ASROT) </li>
            </ul>
        </div>
        <div class="col-md-6">
            <img src="https://www.harapanrakyat.com/wp-content/uploads/2021/06/15.-Aplikasi-Cek-BPOM-Solusi-Tepat-Bagi-Para-Konsumen-Cerdas.jpg" width="100%">
        </div>
    </div>
</div>