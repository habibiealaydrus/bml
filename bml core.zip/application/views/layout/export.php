<div class="container">
    <div class="row">
        <div class="col-md-6">
            <img src="https://www.aseanbriefing.com/news/wp-content/uploads/2018/03/Import-and-Export-Procedures-in-Indonesia.jpg" width="100%">
        </div>
        <div class="col-md-6 subservices">
            <h1>Perizinan Export-Import</h1>
            <h3>Kami Melayani Meliputi Perizinan Export-Import</h3>
            <ul>
                <li>1. Custom clearance</li>
                <li>2. Karantina Tumbuhan</li>
                <li>3. Karantina Hewan</li>
                <li>4. Karantina Ikan</li>
                <li>5. Pembuatan COO</li>
                <li>6. Rekomendasi Pemasukan</li>
                <li>7. Kuota Impor (Ikan, Daging, Tekstil, PI Besi/Baja)</li>
            </ul>
        </div>
    </div>
</div>