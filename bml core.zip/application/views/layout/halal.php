<div class="container">
    <div class="row">
        <div class="col-md-6 subservices">
            <h1>Perizinan Halal</h1>
            <h3>Kami Melayani Perizinan Label Halal</h3>
            <p>
                suatu fatwa tertulis dari Majelis Ulama Indonesia (MUI) yang menyatakan kehalalan suatu produk sesuai dengan syari'at Islam. Sertifikat Halal ini merupakan syarat untuk mendapatkan ijin pencantuman LABEL HALAL pada kemasan produk dari instansi pemerintah yang berwenang
            </p>
        </div>
        <div class="col-md-6">
            <img src="https://statik.tempo.co/data/2022/03/13/id_1094709/1094709_720.jpg" width="100%">
        </div>
    </div>
</div>