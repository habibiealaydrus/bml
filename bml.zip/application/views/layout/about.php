 <!-- About Start -->
 <div class="container-fluid py-5">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-lg-5 pb-4 pb-lg-0">
                 <img class="img-fluid w-100" src="<?= base_url(); ?>/vendor/support/img/gudangkering.jpeg" alt="">
                 <!-- <div class="bg-primary text-dark text-center p-4">
                     <h3 class="m-0">4+ Tahun Pengalaman</h3>
                 </div> -->
             </div>
             <div class="col-lg-7">
                 <h6 class="text-primary text-uppercase font-weight-bold">Tentang Kami</h6>
                 <h1 class="mb-4">Aman Dan Terpercaya</h1>
                 <p class="mb-4">Kami hadir untuk membantu anda dalam hal perizinan dan kepabeanan, pengalaman kami dalam hal perizinan dan kepabeanan serta di bantu dengan tenaga profesional akan memudahkan semua proses yang anda butuhkan. Kami berkomitmen untuk membantu anda, hingga semua kebutuhan perizinan dan kepabenanan untuk bisnis anda terpenuhi.</p>
                 <!-- <div class="d-flex align-items-center pt-2">
                     <button type="button" class="btn-play" data-toggle="modal" data-src="https://www.youtube.com/embed/DWRcNpR6Kdc" data-target="#videoModal">
                         <span></span>
                     </button>
                     <h5 class="font-weight-bold m-0 ml-4">Play Video</h5>
                 </div> -->
             </div>
         </div>
     </div>
     <!-- Video Modal -->
     <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
             <div class="modal-content">
                 <div class="modal-body">
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                     </button>
                     <!-- 16:9 aspect ratio -->
                     <div>
                         <iframe width="800" height="600" src="https://www.youtube.com/embed/6EDCnhbUpgE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- About End -->